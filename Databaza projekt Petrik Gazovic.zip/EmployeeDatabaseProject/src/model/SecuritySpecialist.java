package model;

import java.util.List;

public class SecuritySpecialist extends Employee {
    public SecuritySpecialist(int id, String firstName, String lastName, int birthYear) {
        super(id, firstName, lastName, birthYear);
    }

    @Override
    public String getGroupName() {
        return "Bezpečnostní specialista";
    }

    @Override
    public String executeSkill(List<Employee> allEmployees) {
        int count = getCollaborationCount();
        double average = getAverageCollaborationQuality();

        double riskScore = count * (4.0 - average);

        return "Rizikové skóre spolupráce: " + String.format("%.2f", riskScore) +
                " (počet spolupracovníků: " + count +
                ", průměrná kvalita: " + String.format("%.2f", average) + ")";
    }
}
