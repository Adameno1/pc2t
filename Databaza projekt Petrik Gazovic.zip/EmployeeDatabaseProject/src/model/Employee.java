package model;

import java.util.HashMap;
import java.util.Map;

import service.SkillExecutable;

public abstract class Employee implements SkillExecutable {
    private final int id;
    private final String firstName;
    private final String lastName;
    private final int birthYear;
    private final Map<Integer, CollaborationLevel> collaborations;

    public Employee(int id, String firstName, String lastName, int birthYear) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.birthYear = birthYear;
        this.collaborations = new HashMap<>();
    }

    public int getId() { return id; }
    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
    public int getBirthYear() { return birthYear; }
    public Map<Integer, CollaborationLevel> getCollaborations() { return collaborations; }

    public void addCollaboration(int colleagueId, CollaborationLevel level) {
        if (colleagueId == id) {
            throw new IllegalArgumentException("Zaměstnanec nemůže spolupracovat sám se sebou.");
        }
        collaborations.put(colleagueId, level);
    }

    public void removeCollaboration(int colleagueId) {
        collaborations.remove(colleagueId);
    }

    public int getCollaborationCount() {
        return collaborations.size();
    }

    public double getAverageCollaborationQuality() {
        if (collaborations.isEmpty()) {
            return 0;
        }
        int sum = 0;
        for (CollaborationLevel level : collaborations.values()) {
            sum += level.getValue();
        }
        return (double) sum / collaborations.size();
    }

    public String getBasicInfo() {
        return "ID: " + id + ", jméno: " + firstName + " " + lastName +
                ", rok narození: " + birthYear + ", skupina: " + getGroupName();
    }

    public abstract String getGroupName();

    public String toFileLine() {
        return getGroupName() + ";" + id + ";" + firstName + ";" + lastName + ";" + birthYear;
    }
}
