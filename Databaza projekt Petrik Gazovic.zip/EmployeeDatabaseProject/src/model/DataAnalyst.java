package model;

import java.util.ArrayList;
import java.util.List;

public class DataAnalyst extends Employee {
    public DataAnalyst(int id, String firstName, String lastName, int birthYear) {
        super(id, firstName, lastName, birthYear);
    }

    @Override
    public String getGroupName() {
        return "Datový analytik";
    }

    @Override
    public String executeSkill(List<Employee> allEmployees) {
        int bestId = -1;
        int bestCommon = -1;

        for (Integer colleagueId : getCollaborations().keySet()) {
            Employee colleague = findById(allEmployees, colleagueId);
            if (colleague == null) continue;

            int common = countCommonCollaborators(colleague);
            if (common > bestCommon) {
                bestCommon = common;
                bestId = colleagueId;
            }
        }

        if (bestId == -1) {
            return "Datový analytik nemá žádné spolupracovníky.";
        }

        Employee best = findById(allEmployees, bestId);
        return "Nejvíce společných spolupracovníků má s: " +
                best.getFirstName() + " " + best.getLastName() +
                " (ID " + best.getId() + "), počet společných: " + bestCommon;
    }

    private int countCommonCollaborators(Employee other) {
        List<Integer> common = new ArrayList<>();
        for (Integer id : getCollaborations().keySet()) {
            if (other.getCollaborations().containsKey(id)) {
                common.add(id);
            }
        }
        return common.size();
    }

    private Employee findById(List<Employee> employees, int id) {
        for (Employee employee : employees) {
            if (employee.getId() == id) return employee;
        }
        return null;
    }
}
