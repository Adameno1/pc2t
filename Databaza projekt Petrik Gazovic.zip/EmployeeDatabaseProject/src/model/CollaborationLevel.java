package model;

public enum CollaborationLevel {
    SPATNA(1, "špatná"),
    PRUMERNA(2, "průměrná"),
    DOBRA(3, "dobrá");

    private final int value;
    private final String label;

    CollaborationLevel(int value, String label) {
        this.value = value;
        this.label = label;
    }

    public int getValue() {
        return value;
    }

    public String getLabel() {
        return label;
    }

    public static CollaborationLevel fromNumber(int number) {
        for (CollaborationLevel level : values()) {
            if (level.value == number) {
                return level;
            }
        }
        throw new IllegalArgumentException("Neplatná úroveň spolupráce.");
    }
}
