package persistence;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;

import model.CollaborationLevel;
import model.DataAnalyst;
import model.Employee;
import model.SecuritySpecialist;
import service.EmployeeService;

public class DatabaseManager {
    private static final String URL = "jdbc:sqlite:employees.db";

    public boolean isDriverAvailable() {
        try {
            Class.forName("org.sqlite.JDBC");
            return true;
        } catch (ClassNotFoundException e) {
            return false;
        }
    }

    public void saveAll(EmployeeService service) throws SQLException {
        if (!isDriverAvailable()) {
            System.out.println("SQL ovladač SQLite není dostupný. Program pokračuje bez SQL zálohy.");
            return;
        }

        try (Connection connection = DriverManager.getConnection(URL)) {
            createTables(connection);
            connection.setAutoCommit(false);

            try (Statement statement = connection.createStatement()) {
                statement.executeUpdate("DELETE FROM collaborations");
                statement.executeUpdate("DELETE FROM employees");
            }

            String employeeSql = "INSERT INTO employees(id, first_name, last_name, birth_year, group_name) VALUES(?,?,?,?,?)";
            try (PreparedStatement ps = connection.prepareStatement(employeeSql)) {
                for (Employee employee : service.getEmployees()) {
                    ps.setInt(1, employee.getId());
                    ps.setString(2, employee.getFirstName());
                    ps.setString(3, employee.getLastName());
                    ps.setInt(4, employee.getBirthYear());
                    ps.setString(5, employee.getGroupName());
                    ps.executeUpdate();
                }
            }

            String collaborationSql = "INSERT INTO collaborations(employee_id, colleague_id, level_value) VALUES(?,?,?)";
            try (PreparedStatement ps = connection.prepareStatement(collaborationSql)) {
                for (Employee employee : service.getEmployees()) {
                    for (Map.Entry<Integer, CollaborationLevel> entry : employee.getCollaborations().entrySet()) {
                        if (employee.getId() < entry.getKey()) {
                            ps.setInt(1, employee.getId());
                            ps.setInt(2, entry.getKey());
                            ps.setInt(3, entry.getValue().getValue());
                            ps.executeUpdate();
                        }
                    }
                }
            }

            connection.commit();
        }
    }

    public void loadAll(EmployeeService service) throws SQLException {
        if (!isDriverAvailable()) {
            System.out.println("SQL ovladač SQLite není dostupný. Program pokračuje bez SQL načítání.");
            return;
        }

        try (Connection connection = DriverManager.getConnection(URL)) {
            createTables(connection);
            if (!hasData(connection)) {
                return;
            }

            service.clearAll();

            try (Statement statement = connection.createStatement();
                 ResultSet rs = statement.executeQuery("SELECT id, first_name, last_name, birth_year, group_name FROM employees ORDER BY id")) {
                while (rs.next()) {
                    int id = rs.getInt("id");
                    String firstName = rs.getString("first_name");
                    String lastName = rs.getString("last_name");
                    int birthYear = rs.getInt("birth_year");
                    String groupName = rs.getString("group_name");

                    Employee employee;
                    if (groupName.equals("Datový analytik")) {
                        employee = new DataAnalyst(id, firstName, lastName, birthYear);
                    } else {
                        employee = new SecuritySpecialist(id, firstName, lastName, birthYear);
                    }
                    service.addLoadedEmployee(employee);
                }
            }

            try (Statement statement = connection.createStatement();
                 ResultSet rs = statement.executeQuery("SELECT employee_id, colleague_id, level_value FROM collaborations")) {
                while (rs.next()) {
                    service.addCollaboration(
                            rs.getInt("employee_id"),
                            rs.getInt("colleague_id"),
                            CollaborationLevel.fromNumber(rs.getInt("level_value"))
                    );
                }
            }
        }
    }

    private boolean hasData(Connection connection) throws SQLException {
        try (Statement statement = connection.createStatement();
             ResultSet rs = statement.executeQuery("SELECT COUNT(*) AS count FROM employees")) {
            return rs.next() && rs.getInt("count") > 0;
        }
    }

    private void createTables(Connection connection) throws SQLException {
        try (Statement statement = connection.createStatement()) {
            statement.executeUpdate("CREATE TABLE IF NOT EXISTS employees (" +
                    "id INTEGER PRIMARY KEY, " +
                    "first_name TEXT NOT NULL, " +
                    "last_name TEXT NOT NULL, " +
                    "birth_year INTEGER NOT NULL, " +
                    "group_name TEXT NOT NULL)");

            statement.executeUpdate("CREATE TABLE IF NOT EXISTS collaborations (" +
                    "employee_id INTEGER NOT NULL, " +
                    "colleague_id INTEGER NOT NULL, " +
                    "level_value INTEGER NOT NULL, " +
                    "PRIMARY KEY(employee_id, colleague_id), " +
                    "FOREIGN KEY(employee_id) REFERENCES employees(id), " +
                    "FOREIGN KEY(colleague_id) REFERENCES employees(id))");
        }
    }
}
