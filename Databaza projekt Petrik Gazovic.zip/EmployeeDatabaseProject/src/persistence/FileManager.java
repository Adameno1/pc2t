package persistence;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import model.CollaborationLevel;
import model.DataAnalyst;
import model.Employee;
import model.SecuritySpecialist;
import service.EmployeeService;

public class FileManager {
    public void saveEmployees(EmployeeService service, String fileName) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            writer.write("#EMPLOYEES");
            writer.newLine();
            for (Employee employee : service.getEmployees()) {
                writer.write(employee.toFileLine());
                writer.newLine();
            }

            writer.write("#COLLABORATIONS");
            writer.newLine();
            for (Employee employee : service.getEmployees()) {
                for (Map.Entry<Integer, CollaborationLevel> entry : employee.getCollaborations().entrySet()) {
                    if (employee.getId() < entry.getKey()) {
                        writer.write(employee.getId() + ";" + entry.getKey() + ";" + entry.getValue().getValue());
                        writer.newLine();
                    }
                }
            }
        }
    }

    public void loadEmployees(EmployeeService service, String fileName) throws IOException {
        List<String> collaborationLines = new ArrayList<>();
        service.clearAll();
        boolean readingCollaborations = false;

        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.isBlank()) continue;
                if (line.equals("#EMPLOYEES")) {
                    readingCollaborations = false;
                    continue;
                }
                if (line.equals("#COLLABORATIONS")) {
                    readingCollaborations = true;
                    continue;
                }

                if (readingCollaborations) {
                    collaborationLines.add(line);
                } else {
                    String[] parts = line.split(";");
                    if (parts.length != 5) continue;

                    String group = parts[0];
                    int id = Integer.parseInt(parts[1]);
                    String firstName = parts[2];
                    String lastName = parts[3];
                    int birthYear = Integer.parseInt(parts[4]);

                    Employee employee;
                    if (group.equals("Datový analytik")) {
                        employee = new DataAnalyst(id, firstName, lastName, birthYear);
                    } else {
                        employee = new SecuritySpecialist(id, firstName, lastName, birthYear);
                    }
                    service.addLoadedEmployee(employee);
                }
            }
        }

        for (String line : collaborationLines) {
            String[] parts = line.split(";");
            if (parts.length != 3) continue;
            int employeeId = Integer.parseInt(parts[0]);
            int colleagueId = Integer.parseInt(parts[1]);
            int level = Integer.parseInt(parts[2]);
            service.addCollaboration(employeeId, colleagueId, CollaborationLevel.fromNumber(level));
        }
    }
}
