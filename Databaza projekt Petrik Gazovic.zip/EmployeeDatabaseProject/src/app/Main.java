package app;

import java.util.InputMismatchException;
import java.util.Scanner;

import model.CollaborationLevel;
import model.Employee;
import persistence.DatabaseManager;
import persistence.FileManager;
import service.EmployeeService;

public class Main {
    private static final Scanner scanner = new Scanner(System.in);
    private static final EmployeeService employeeService = new EmployeeService();
    private static final FileManager fileManager = new FileManager();
    private static final DatabaseManager databaseManager = new DatabaseManager();

    public static void main(String[] args) {
        seedData();
        databaseManagerLoad();

        boolean running = true;
        while (running) {
            printMenu();
            int choice = readInt("Volba: ");
            System.out.println();

            try {
                switch (choice) {
                    case 1 -> addEmployee();
                    case 2 -> addCollaboration();
                    case 3 -> removeEmployee();
                    case 4 -> findEmployee();
                    case 5 -> runEmployeeSkill();
                    case 6 -> System.out.println(employeeService.alphabeticalPrintByGroups());
                    case 7 -> System.out.println(employeeService.statistics());
                    case 8 -> System.out.println(employeeService.groupCounts());
                    case 9 -> saveToFile();
                    case 10 -> loadFromFile();
                    case 11 -> databaseManagerSave();
                    case 0 -> {
                        databaseManagerSave();
                        running = false;
                        System.out.println("Program byl ukončen.");
                    }
                    default -> System.out.println("Neplatná volba.");
                }
            } catch (Exception e) {
                System.out.println("Chyba: " + e.getMessage());
            }
            System.out.println();
        }
    }

    private static void printMenu() {
        System.out.println("===== Databázový systém zaměstnanců =====");
        System.out.println("1 - Přidat zaměstnance");
        System.out.println("2 - Přidat spolupráci");
        System.out.println("3 - Odebrat zaměstnance");
        System.out.println("4 - Vyhledat zaměstnance dle ID");
        System.out.println("5 - Spustit dovednost zaměstnance");
        System.out.println("6 - Abecední výpis zaměstnanců ve skupinách");
        System.out.println("7 - Statistiky");
        System.out.println("8 - Počet zaměstnanců ve skupinách");
        System.out.println("9 - Uložit zaměstnance do souboru");
        System.out.println("10 - Načíst zaměstnance ze souboru");
        System.out.println("11 - Uložit všechna data do SQL databáze");
        System.out.println("0 - Konec");
    }

    private static void addEmployee() {
        System.out.println("Skupina: 1 = Datový analytik, 2 = Bezpečnostní specialista");
        int group = readInt("Zadej skupinu: ");
        String firstName = readString("Jméno: ");
        String lastName = readString("Příjmení: ");
        int birthYear = readInt("Rok narození: ");

        Employee employee = employeeService.addEmployee(group, firstName, lastName, birthYear);
        System.out.println("Zaměstnanec přidán. Přidělené ID: " + employee.getId());
    }

    private static void addCollaboration() {
        int employeeId = readInt("ID zaměstnance: ");
        int colleagueId = readInt("ID kolegy: ");
        System.out.println("Úroveň spolupráce: 1 = špatná, 2 = průměrná, 3 = dobrá");
        int levelNumber = readInt("Úroveň: ");

        boolean success = employeeService.addCollaboration(employeeId, colleagueId,
                CollaborationLevel.fromNumber(levelNumber));
        if (success) {
            System.out.println("Spolupráce byla přidána.");
        } else {
            System.out.println("Spolupráci se nepodařilo přidat. Zkontroluj ID.");
        }
    }

    private static void removeEmployee() {
        int id = readInt("ID zaměstnance k odebrání: ");
        if (employeeService.removeEmployee(id)) {
            System.out.println("Zaměstnanec byl odebrán včetně všech vazeb.");
        } else {
            System.out.println("Zaměstnanec nebyl nalezen.");
        }
    }

    private static void findEmployee() {
        int id = readInt("ID zaměstnance: ");
        System.out.println(employeeService.employeeDetails(id));
    }

    private static void runEmployeeSkill() {
        int id = readInt("ID zaměstnance: ");
        System.out.println(employeeService.executeSkill(id));
    }

    private static void saveToFile() throws Exception {
        String fileName = readString("Název souboru: ");
        fileManager.saveEmployees(employeeService, fileName);
        System.out.println("Zaměstnanci byli uloženi do souboru.");
    }

    private static void loadFromFile() throws Exception {
        String fileName = readString("Název souboru: ");
        fileManager.loadEmployees(employeeService, fileName);
        System.out.println("Zaměstnanci byli načteni ze souboru.");
    }

    private static void databaseManagerSave() {
        try {
            databaseManager.saveAll(employeeService);
        } catch (Exception e) {
            System.out.println("SQL uložení se nezdařilo: " + e.getMessage());
        }
    }

    private static void databaseManagerLoad() {
        try {
            databaseManager.loadAll(employeeService);
        } catch (Exception e) {
            System.out.println("SQL načítání se nezdařilo: " + e.getMessage());
        }
    }

    private static int readInt(String message) {
        while (true) {
            try {
                System.out.print(message);
                int value = scanner.nextInt();
                scanner.nextLine();
                return value;
            } catch (InputMismatchException e) {
                scanner.nextLine();
                System.out.println("Zadej celé číslo.");
            }
        }
    }

    private static String readString(String message) {
        System.out.print(message);
        return scanner.nextLine().trim();
    }

    private static void seedData() {
        Employee a = employeeService.addEmployee(1, "Jan", "Novák", 1998);
        Employee b = employeeService.addEmployee(2, "Petr", "Svoboda", 1996);
        Employee c = employeeService.addEmployee(1, "Eva", "Dvořáková", 2000);
        Employee d = employeeService.addEmployee(2, "Lucie", "Malá", 1999);

        employeeService.addCollaboration(a.getId(), b.getId(), CollaborationLevel.DOBRA);
        employeeService.addCollaboration(a.getId(), c.getId(), CollaborationLevel.PRUMERNA);
        employeeService.addCollaboration(b.getId(), d.getId(), CollaborationLevel.SPATNA);
        employeeService.addCollaboration(c.getId(), d.getId(), CollaborationLevel.DOBRA);
    }
}
