package service;

import java.util.List;
import model.Employee;

public interface SkillExecutable {
    String executeSkill(List<Employee> allEmployees);
}
