package service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import model.CollaborationLevel;
import model.DataAnalyst;
import model.Employee;
import model.SecuritySpecialist;

public class EmployeeService {
    private final List<Employee> employees = new ArrayList<>();
    private int nextId = 1;

    public List<Employee> getEmployees() {
        return employees;
    }

    public Employee addEmployee(int groupChoice, String firstName, String lastName, int birthYear) {
        Employee employee;
        if (groupChoice == 1) {
            employee = new DataAnalyst(nextId++, firstName, lastName, birthYear);
        } else if (groupChoice == 2) {
            employee = new SecuritySpecialist(nextId++, firstName, lastName, birthYear);
        } else {
            throw new IllegalArgumentException("Neplatná skupina.");
        }
        employees.add(employee);
        return employee;
    }

    public void addLoadedEmployee(Employee employee) {
        employees.add(employee);
        if (employee.getId() >= nextId) {
            nextId = employee.getId() + 1;
        }
    }

    public Employee findById(int id) {
        for (Employee employee : employees) {
            if (employee.getId() == id) return employee;
        }
        return null;
    }

    public boolean addCollaboration(int employeeId, int colleagueId, CollaborationLevel level) {
        Employee employee = findById(employeeId);
        Employee colleague = findById(colleagueId);
        if (employee == null || colleague == null || employeeId == colleagueId) {
            return false;
        }
        employee.addCollaboration(colleagueId, level);
        colleague.addCollaboration(employeeId, level);
        return true;
    }

    public boolean removeEmployee(int id) {
        Employee removed = findById(id);
        if (removed == null) return false;

        employees.remove(removed);
        for (Employee employee : employees) {
            employee.removeCollaboration(id);
        }
        return true;
    }

    public String employeeDetails(int id) {
        Employee employee = findById(id);
        if (employee == null) return "Zaměstnanec nebyl nalezen.";

        StringBuilder sb = new StringBuilder();
        sb.append(employee.getBasicInfo()).append("\n");
        sb.append("Počet spolupracovníků: ").append(employee.getCollaborationCount()).append("\n");
        sb.append("Průměrná kvalita spolupráce: ")
                .append(String.format("%.2f", employee.getAverageCollaborationQuality())).append("\n");
        sb.append("Spolupracovníci:\n");
        if (employee.getCollaborations().isEmpty()) {
            sb.append("- žádní\n");
        } else {
            for (Map.Entry<Integer, CollaborationLevel> entry : employee.getCollaborations().entrySet()) {
                Employee colleague = findById(entry.getKey());
                String name = colleague == null ? "neznámý" : colleague.getFirstName() + " " + colleague.getLastName();
                sb.append("- ID ").append(entry.getKey()).append(" - ").append(name)
                        .append("; kvalita: ").append(entry.getValue().getLabel()).append("\n");
            }
        }
        return sb.toString();
    }

    public String executeSkill(int id) {
        Employee employee = findById(id);
        if (employee == null) return "Zaměstnanec nebyl nalezen.";
        return employee.executeSkill(employees);
    }

    public String alphabeticalPrintByGroups() {
        StringBuilder sb = new StringBuilder();
        appendGroup(sb, "Datový analytik");
        appendGroup(sb, "Bezpečnostní specialista");
        return sb.toString();
    }

    private void appendGroup(StringBuilder sb, String groupName) {
        sb.append("\n").append(groupName).append(":\n");
        employees.stream()
                .filter(e -> e.getGroupName().equals(groupName))
                .sorted(Comparator.comparing(Employee::getLastName).thenComparing(Employee::getFirstName))
                .forEach(e -> sb.append(e.getId()).append(" - ")
                        .append(e.getLastName()).append(" ").append(e.getFirstName())
                        .append(" (" + e.getBirthYear() + ")\n"));
    }

    public String statistics() {
        StringBuilder sb = new StringBuilder();
        sb.append("Převažující kvalita spolupráce: ").append(mostCommonCollaborationQuality()).append("\n");
        Employee max = null;
        for (Employee employee : employees) {
            if (max == null || employee.getCollaborationCount() > max.getCollaborationCount()) {
                max = employee;
            }
        }
        if (max == null) {
            sb.append("Zaměstnanec s nejvíce vazbami: žádný\n");
        } else {
            sb.append("Zaměstnanec s nejvíce vazbami: ")
                    .append(max.getFirstName()).append(" ").append(max.getLastName())
                    .append(" (ID ").append(max.getId()).append(", vazby: ")
                    .append(max.getCollaborationCount()).append(")\n");
        }
        return sb.toString();
    }

    private String mostCommonCollaborationQuality() {
        Map<CollaborationLevel, Integer> counts = new HashMap<>();
        for (Employee employee : employees) {
            for (CollaborationLevel level : employee.getCollaborations().values()) {
                counts.put(level, counts.getOrDefault(level, 0) + 1);
            }
        }
        if (counts.isEmpty()) return "žádná data";

        CollaborationLevel best = null;
        int bestCount = -1;
        for (Map.Entry<CollaborationLevel, Integer> entry : counts.entrySet()) {
            if (entry.getValue() > bestCount) {
                best = entry.getKey();
                bestCount = entry.getValue();
            }
        }
        return best.getLabel();
    }

    public String groupCounts() {
        int analysts = 0;
        int specialists = 0;
        for (Employee employee : employees) {
            if (employee instanceof DataAnalyst) analysts++;
            if (employee instanceof SecuritySpecialist) specialists++;
        }
        return "Datoví analytici: " + analysts + "\nBezpečnostní specialisté: " + specialists;
    }

    public void clearAll() {
        employees.clear();
        nextId = 1;
    }
}
