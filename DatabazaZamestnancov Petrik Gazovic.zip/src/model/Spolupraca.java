package model;

public class Spolupraca {
    private int idKolegu;
    private UrovenSpoluprace uroven;

    public Spolupraca(int idKolegu, UrovenSpoluprace uroven) {
        this.idKolegu = idKolegu;
        this.uroven = uroven;
    }

    public int getIdKolegu() {
        return idKolegu;
    }

    public UrovenSpoluprace getUroven() {
        return uroven;
    }

    @Override
    public String toString() {
        return "ID kolegu: " + idKolegu + ", uroven: " + uroven;
    }
}
