package model;

public enum UrovenSpoluprace {
    ZLA,
    PRIEMERNA,
    DOBRA;

    public static UrovenSpoluprace zCisla(int cislo) {
        switch (cislo) {
            case 1:
                return ZLA;
            case 2:
                return PRIEMERNA;
            case 3:
                return DOBRA;
            default:
                return PRIEMERNA;
        }
    }
}
