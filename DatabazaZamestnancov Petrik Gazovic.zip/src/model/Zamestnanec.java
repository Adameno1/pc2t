package model;

import java.util.ArrayList;

public abstract class Zamestnanec implements Schopnost {
    private int id;
    private String meno;
    private String priezvisko;
    private int rokNarodenia;
    private ArrayList<Spolupraca> spoluprace;

    public Zamestnanec(int id, String meno, String priezvisko, int rokNarodenia) {
        this.id = id;
        this.meno = meno;
        this.priezvisko = priezvisko;
        this.rokNarodenia = rokNarodenia;
        this.spoluprace = new ArrayList<>();
    }

    public int getId() {
        return id;
    }

    public String getMeno() {
        return meno;
    }

    public String getPriezvisko() {
        return priezvisko;
    }

    public int getRokNarodenia() {
        return rokNarodenia;
    }

    public ArrayList<Spolupraca> getSpoluprace() {
        return spoluprace;
    }

    public void pridajSpolupracu(int idKolegu, UrovenSpoluprace uroven) {
        spoluprace.add(new Spolupraca(idKolegu, uroven));
    }

    public void odstranSpolupracuNaZamestnanca(int idZamestnanca) {
        spoluprace.removeIf(s -> s.getIdKolegu() == idZamestnanca);
    }

    public abstract String getSkupina();

    public String zakladnyVypis() {
        return "ID: " + id + ", meno: " + meno + " " + priezvisko +
                ", rok narodenia: " + rokNarodenia + ", skupina: " + getSkupina();
    }

    public void vypisDetail() {
        System.out.println(zakladnyVypis());
        System.out.println("Pocet spoluprac: " + spoluprace.size());
        if (spoluprace.isEmpty()) {
            System.out.println("Ziadne spoluprace.");
        } else {
            for (Spolupraca s : spoluprace) {
                System.out.println(" - " + s);
            }
        }
    }
}
