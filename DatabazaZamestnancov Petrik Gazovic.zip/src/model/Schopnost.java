package model;

import service.DatabazaZamestnancov;

public interface Schopnost {
    void spustiSchopnost(DatabazaZamestnancov databaza);
}
