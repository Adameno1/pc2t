package model;

import service.DatabazaZamestnancov;

public class BezpecnostnySpecialista extends Zamestnanec {

    public BezpecnostnySpecialista(int id, String meno, String priezvisko, int rokNarodenia) {
        super(id, meno, priezvisko, rokNarodenia);
    }

    @Override
    public String getSkupina() {
        return "Bezpecnostny specialista";
    }

    @Override
    public void spustiSchopnost(DatabazaZamestnancov databaza) {
        int riziko = 0;

        for (Spolupraca s : getSpoluprace()) {
            if (s.getUroven() == UrovenSpoluprace.ZLA) {
                riziko += 3;
            } else if (s.getUroven() == UrovenSpoluprace.PRIEMERNA) {
                riziko += 2;
            } else {
                riziko += 1;
            }
        }

        System.out.println("Schopnost bezpecnostneho specialistu:");
        System.out.println("Rizikove skore spoluprace je: " + riziko);
        if (riziko >= 8) {
            System.out.println("Vyhodnotenie: vyssie riziko spoluprace.");
        } else if (riziko >= 4) {
            System.out.println("Vyhodnotenie: stredne riziko spoluprace.");
        } else {
            System.out.println("Vyhodnotenie: nizke riziko spoluprace.");
        }
    }
}
