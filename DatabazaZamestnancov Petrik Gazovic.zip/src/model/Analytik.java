package model;

import service.DatabazaZamestnancov;

public class Analytik extends Zamestnanec {

    public Analytik(int id, String meno, String priezvisko, int rokNarodenia) {
        super(id, meno, priezvisko, rokNarodenia);
    }

    @Override
    public String getSkupina() {
        return "Datovy analytik";
    }

    @Override
    public void spustiSchopnost(DatabazaZamestnancov databaza) {
        System.out.println("Schopnost datoveho analytika:");
        System.out.println("Hladam zamestnanca, s ktorym mam najviac spolocnych spolupracovnikov...");
        databaza.najdiNajviacSpolocnychSpolupracovnikov(getId());
    }
}
