package app;

import java.util.Scanner;

import io.SQLManager;
import io.SuborManager;
import model.UrovenSpoluprace;
import model.Zamestnanec;
import service.DatabazaZamestnancov;

public class Main {
    private static Scanner sc = new Scanner(System.in);
    private static DatabazaZamestnancov databaza = new DatabazaZamestnancov();

    public static void main(String[] args) {
        SQLManager.nacitajSQLZalohu(databaza);

        boolean bezi = true;
        while (bezi) {
            vypisMenu();
            int volba = nacitajInt("Zadaj volbu: ");

            switch (volba) {
                case 1:
                    pridajZamestnanca();
                    break;
                case 2:
                    pridajSpolupracu();
                    break;
                case 3:
                    odoberZamestnanca();
                    break;
                case 4:
                    vyhladajZamestnanca();
                    break;
                case 5:
                    spustiSchopnost();
                    break;
                case 6:
                    databaza.vypisPodlaPriezviskaVSkupinach();
                    break;
                case 7:
                    databaza.statistiky();
                    break;
                case 8:
                    databaza.vypisPoctySkupin();
                    break;
                case 9:
                    SuborManager.ulozDoSuboru(databaza);
                    break;
                case 10:
                    SuborManager.nacitajZoSuboru(databaza);
                    break;
                case 11:
                    SQLManager.ulozSQLZalohu(databaza);
                    break;
                case 12:
                    SQLManager.nacitajSQLZalohu(databaza);
                    break;
                case 0:
                    SQLManager.ulozSQLZalohu(databaza);
                    System.out.println("Program sa ukoncuje.");
                    bezi = false;
                    break;
                default:
                    System.out.println("Neplatna volba.");
            }

            System.out.println();
        }
    }

    private static void vypisMenu() {
        System.out.println("===== DATABAZA ZAMESTNANCOV =====");
        System.out.println("1  - Pridat zamestnanca");
        System.out.println("2  - Pridat spolupracu");
        System.out.println("3  - Odobrat zamestnanca");
        System.out.println("4  - Vyhladat zamestnanca podla ID");
        System.out.println("5  - Spustit schopnost zamestnanca");
        System.out.println("6  - Abecedny vypis zamestnancov v skupinach");
        System.out.println("7  - Statistiky");
        System.out.println("8  - Vypis poctu zamestnancov v skupinach");
        System.out.println("9  - Ulozit do suboru");
        System.out.println("10 - Nacitat zo suboru");
        System.out.println("11 - Ulozit SQL zalohu");
        System.out.println("12 - Nacitat SQL zalohu");
        System.out.println("0  - Koniec");
    }

    private static void pridajZamestnanca() {
        System.out.println("Vyber skupinu:");
        System.out.println("1 - Datovy analytik");
        System.out.println("2 - Bezpecnostny specialista");
        int skupina = nacitajInt("Skupina: ");

        if (skupina != 1 && skupina != 2) {
            System.out.println("Neplatna skupina.");
            return;
        }

        System.out.print("Meno: ");
        String meno = sc.nextLine();
        System.out.print("Priezvisko: ");
        String priezvisko = sc.nextLine();
        int rok = nacitajInt("Rok narodenia: ");

        Zamestnanec z = databaza.pridajZamestnanca(skupina, meno, priezvisko, rok);
        System.out.println("Zamestnanec bol pridany. Pridelene ID: " + z.getId());
    }

    private static void pridajSpolupracu() {
        int idZ = nacitajInt("ID zamestnanca: ");
        int idK = nacitajInt("ID kolegu: ");

        System.out.println("Uroven spoluprace:");
        System.out.println("1 - zla");
        System.out.println("2 - priemerna");
        System.out.println("3 - dobra");
        int urovenCislo = nacitajInt("Volba: ");

        UrovenSpoluprace uroven = UrovenSpoluprace.zCisla(urovenCislo);
        boolean ok = databaza.pridajSpolupracu(idZ, idK, uroven);

        if (ok) {
            System.out.println("Spolupraca bola pridana.");
        } else {
            System.out.println("Spolupracu sa nepodarilo pridat. Skontroluj ID.");
        }
    }

    private static void odoberZamestnanca() {
        int id = nacitajInt("Zadaj ID zamestnanca na odstranenie: ");
        if (databaza.odoberZamestnanca(id)) {
            System.out.println("Zamestnanec bol odstraneny aj so vsetkymi vazbami.");
        } else {
            System.out.println("Zamestnanec neexistuje.");
        }
    }

    private static void vyhladajZamestnanca() {
        int id = nacitajInt("Zadaj ID: ");
        Zamestnanec z = databaza.najdiPodlaId(id);
        if (z == null) {
            System.out.println("Zamestnanec neexistuje.");
        } else {
            z.vypisDetail();
        }
    }

    private static void spustiSchopnost() {
        int id = nacitajInt("Zadaj ID zamestnanca: ");
        Zamestnanec z = databaza.najdiPodlaId(id);
        if (z == null) {
            System.out.println("Zamestnanec neexistuje.");
        } else {
            z.spustiSchopnost(databaza);
        }
    }

    private static int nacitajInt(String text) {
        while (true) {
            try {
                System.out.print(text);
                int cislo = Integer.parseInt(sc.nextLine());
                return cislo;
            } catch (Exception e) {
                System.out.println("Zadaj cele cislo.");
            }
        }
    }
}
