package service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;

import model.Analytik;
import model.BezpecnostnySpecialista;
import model.Spolupraca;
import model.UrovenSpoluprace;
import model.Zamestnanec;

public class DatabazaZamestnancov {
    private HashMap<Integer, Zamestnanec> zamestnanci;
    private int dalsieId;

    public DatabazaZamestnancov() {
        zamestnanci = new HashMap<>();
        dalsieId = 1;
    }

    public HashMap<Integer, Zamestnanec> getZamestnanci() {
        return zamestnanci;
    }

    public int getDalsieId() {
        return dalsieId;
    }

    public void setDalsieId(int dalsieId) {
        this.dalsieId = dalsieId;
    }

    public void vymazVsetko() {
        zamestnanci.clear();
        dalsieId = 1;
    }

    public Zamestnanec pridajZamestnanca(int skupina, String meno, String priezvisko, int rokNarodenia) {
        Zamestnanec z;
        int id = dalsieId;
        dalsieId++;

        if (skupina == 1) {
            z = new Analytik(id, meno, priezvisko, rokNarodenia);
        } else {
            z = new BezpecnostnySpecialista(id, meno, priezvisko, rokNarodenia);
        }

        zamestnanci.put(id, z);
        return z;
    }

    public Zamestnanec pridajZamestnancaSPevnymId(int id, String typ, String meno, String priezvisko, int rokNarodenia) {
        Zamestnanec z;
        if (typ.equals("ANALYTIK")) {
            z = new Analytik(id, meno, priezvisko, rokNarodenia);
        } else {
            z = new BezpecnostnySpecialista(id, meno, priezvisko, rokNarodenia);
        }

        zamestnanci.put(id, z);
        if (id >= dalsieId) {
            dalsieId = id + 1;
        }
        return z;
    }

    public boolean pridajSpolupracu(int idZamestnanca, int idKolegu, UrovenSpoluprace uroven) {
        Zamestnanec z = zamestnanci.get(idZamestnanca);
        Zamestnanec kolega = zamestnanci.get(idKolegu);

        if (z == null || kolega == null || idZamestnanca == idKolegu) {
            return false;
        }

        z.pridajSpolupracu(idKolegu, uroven);
        return true;
    }

    public boolean odoberZamestnanca(int id) {
        if (!zamestnanci.containsKey(id)) {
            return false;
        }

        zamestnanci.remove(id);

        for (Zamestnanec z : zamestnanci.values()) {
            z.odstranSpolupracuNaZamestnanca(id);
        }

        return true;
    }

    public Zamestnanec najdiPodlaId(int id) {
        return zamestnanci.get(id);
    }

    public void vypisPodlaPriezviskaVSkupinach() {
        ArrayList<Zamestnanec> analytici = new ArrayList<>();
        ArrayList<Zamestnanec> specialisti = new ArrayList<>();

        for (Zamestnanec z : zamestnanci.values()) {
            if (z instanceof Analytik) {
                analytici.add(z);
            } else {
                specialisti.add(z);
            }
        }

        Comparator<Zamestnanec> podlaPriezviska = Comparator.comparing(Zamestnanec::getPriezvisko);
        Collections.sort(analytici, podlaPriezviska);
        Collections.sort(specialisti, podlaPriezviska);

        System.out.println("Datovi analytici:");
        for (Zamestnanec z : analytici) {
            System.out.println(z.zakladnyVypis());
        }

        System.out.println("Bezpecnostni specialisti:");
        for (Zamestnanec z : specialisti) {
            System.out.println(z.zakladnyVypis());
        }
    }

    public void statistiky() {
        if (zamestnanci.isEmpty()) {
            System.out.println("Databaza je prazdna.");
            return;
        }

        Zamestnanec najviacVazieb = null;
        int pocetZla = 0;
        int pocetPriemerna = 0;
        int pocetDobra = 0;

        for (Zamestnanec z : zamestnanci.values()) {
            if (najviacVazieb == null || z.getSpoluprace().size() > najviacVazieb.getSpoluprace().size()) {
                najviacVazieb = z;
            }

            for (Spolupraca s : z.getSpoluprace()) {
                if (s.getUroven() == UrovenSpoluprace.ZLA) pocetZla++;
                if (s.getUroven() == UrovenSpoluprace.PRIEMERNA) pocetPriemerna++;
                if (s.getUroven() == UrovenSpoluprace.DOBRA) pocetDobra++;
            }
        }

        System.out.println("Zamestnanec s najviac vazbami:");
        System.out.println(najviacVazieb.zakladnyVypis());
        System.out.println("Pocet vazieb: " + najviacVazieb.getSpoluprace().size());

        String prevazuje = "DOBRA";
        int max = pocetDobra;
        if (pocetPriemerna > max) {
            prevazuje = "PRIEMERNA";
            max = pocetPriemerna;
        }
        if (pocetZla > max) {
            prevazuje = "ZLA";
        }

        System.out.println("Prevazujuca kvalita spoluprace: " + prevazuje);
        System.out.println("ZLA: " + pocetZla + ", PRIEMERNA: " + pocetPriemerna + ", DOBRA: " + pocetDobra);
    }

    public void vypisPoctySkupin() {
        int analytici = 0;
        int specialisti = 0;

        for (Zamestnanec z : zamestnanci.values()) {
            if (z instanceof Analytik) analytici++;
            else specialisti++;
        }

        System.out.println("Pocet datovych analytikov: " + analytici);
        System.out.println("Pocet bezpecnostnych specialistov: " + specialisti);
    }

    public void najdiNajviacSpolocnychSpolupracovnikov(int id) {
        Zamestnanec hlavny = zamestnanci.get(id);
        if (hlavny == null) {
            System.out.println("Zamestnanec neexistuje.");
            return;
        }

        HashSet<Integer> hlavneSpoluprace = new HashSet<>();
        for (Spolupraca s : hlavny.getSpoluprace()) {
            hlavneSpoluprace.add(s.getIdKolegu());
        }

        Zamestnanec najlepsi = null;
        int najviac = -1;

        for (Zamestnanec iny : zamestnanci.values()) {
            if (iny.getId() == id) continue;

            int spolocne = 0;
            for (Spolupraca s : iny.getSpoluprace()) {
                if (hlavneSpoluprace.contains(s.getIdKolegu())) {
                    spolocne++;
                }
            }

            if (spolocne > najviac) {
                najviac = spolocne;
                najlepsi = iny;
            }
        }

        if (najlepsi == null) {
            System.out.println("Nie je s kym porovnavat.");
        } else {
            System.out.println("Najviac spolocnych spolupracovnikov ma s:");
            System.out.println(najlepsi.zakladnyVypis());
            System.out.println("Pocet spolocnych spolupracovnikov: " + najviac);
        }
    }
}
