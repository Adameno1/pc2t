package io;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;

import model.Analytik;
import model.Spolupraca;
import model.UrovenSpoluprace;
import model.Zamestnanec;
import service.DatabazaZamestnancov;

public class SQLManager {
    private static final String SQL_SUBOR = "databaza.sql";

    public static void ulozSQLZalohu(DatabazaZamestnancov db) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(SQL_SUBOR))) {
            pw.println("-- Jednoducha SQL zaloha projektu");
            pw.println("DROP TABLE IF EXISTS spoluprace;");
            pw.println("DROP TABLE IF EXISTS zamestnanci;");
            pw.println("CREATE TABLE zamestnanci (id INTEGER, typ TEXT, meno TEXT, priezvisko TEXT, rok INTEGER);");
            pw.println("CREATE TABLE spoluprace (id_zamestnanca INTEGER, id_kolegu INTEGER, uroven TEXT);");
            pw.println("-- NEXT_ID=" + db.getDalsieId());

            for (Zamestnanec z : db.getZamestnanci().values()) {
                String typ = (z instanceof Analytik) ? "ANALYTIK" : "BEZPECNOST";
                pw.println("INSERT INTO zamestnanci VALUES (" + z.getId() + ", '" + typ + "', '" + z.getMeno() + "', '" + z.getPriezvisko() + "', " + z.getRokNarodenia() + ");");

                for (Spolupraca s : z.getSpoluprace()) {
                    pw.println("INSERT INTO spoluprace VALUES (" + z.getId() + ", " + s.getIdKolegu() + ", '" + s.getUroven() + "');");
                }
            }
            System.out.println("SQL zaloha bola ulozena do suboru databaza.sql.");
        } catch (Exception e) {
            System.out.println("Chyba pri ukladani SQL zalohy: " + e.getMessage());
        }
    }

    public static void nacitajSQLZalohu(DatabazaZamestnancov db) {
        File f = new File(SQL_SUBOR);
        if (!f.exists()) {
            System.out.println("SQL zaloha este neexistuje, program zacina s prazdnou databazou.");
            return;
        }

        try (BufferedReader br = new BufferedReader(new FileReader(SQL_SUBOR))) {
            db.vymazVsetko();
            String riadok;

            while ((riadok = br.readLine()) != null) {
                riadok = riadok.trim();

                if (riadok.startsWith("-- NEXT_ID=")) {
                    int next = Integer.parseInt(riadok.substring(11));
                    db.setDalsieId(next);
                }

                if (riadok.startsWith("INSERT INTO zamestnanci")) {
                    String v = riadok.substring(riadok.indexOf("(") + 1, riadok.lastIndexOf(")"));
                    String[] p = rozdelSQL(v);
                    int id = Integer.parseInt(p[0].trim());
                    String typ = odoberUvodzovky(p[1]);
                    String meno = odoberUvodzovky(p[2]);
                    String priezvisko = odoberUvodzovky(p[3]);
                    int rok = Integer.parseInt(p[4].trim());
                    db.pridajZamestnancaSPevnymId(id, typ, meno, priezvisko, rok);
                }

                if (riadok.startsWith("INSERT INTO spoluprace")) {
                    String v = riadok.substring(riadok.indexOf("(") + 1, riadok.lastIndexOf(")"));
                    String[] p = rozdelSQL(v);
                    int idZ = Integer.parseInt(p[0].trim());
                    int idK = Integer.parseInt(p[1].trim());
                    UrovenSpoluprace uroven = UrovenSpoluprace.valueOf(odoberUvodzovky(p[2]));
                    db.pridajSpolupracu(idZ, idK, uroven);
                }
            }
            System.out.println("SQL zaloha bola nacitana.");
        } catch (Exception e) {
            System.out.println("SQL zalohu sa nepodarilo nacitat: " + e.getMessage());
        }
    }

    private static String[] rozdelSQL(String text) {
        return text.split(",(?=(?:[^']*'[^']*')*[^']*$)");
    }

    private static String odoberUvodzovky(String s) {
        s = s.trim();
        if (s.startsWith("'") && s.endsWith("'")) {
            return s.substring(1, s.length() - 1);
        }
        return s;
    }
}
