package io;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;

import model.Analytik;
import model.Spolupraca;
import model.UrovenSpoluprace;
import model.Zamestnanec;
import service.DatabazaZamestnancov;

public class SuborManager {
    private static final String SUBOR = "zamestnanci.txt";

    public static void ulozDoSuboru(DatabazaZamestnancov db) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(SUBOR))) {
            pw.println("NEXT_ID;" + db.getDalsieId());

            for (Zamestnanec z : db.getZamestnanci().values()) {
                String typ = (z instanceof Analytik) ? "ANALYTIK" : "BEZPECNOST";
                pw.println("Z;" + z.getId() + ";" + typ + ";" + z.getMeno() + ";" + z.getPriezvisko() + ";" + z.getRokNarodenia());

                for (Spolupraca s : z.getSpoluprace()) {
                    pw.println("S;" + z.getId() + ";" + s.getIdKolegu() + ";" + s.getUroven());
                }
            }
            System.out.println("Data boli ulozene do suboru.");
        } catch (Exception e) {
            System.out.println("Chyba pri ukladani do suboru: " + e.getMessage());
        }
    }

    public static void nacitajZoSuboru(DatabazaZamestnancov db) {
        try (BufferedReader br = new BufferedReader(new FileReader(SUBOR))) {
            db.vymazVsetko();
            String riadok;

            while ((riadok = br.readLine()) != null) {
                String[] p = riadok.split(";");
                if (p[0].equals("NEXT_ID")) {
                    db.setDalsieId(Integer.parseInt(p[1]));
                } else if (p[0].equals("Z")) {
                    int id = Integer.parseInt(p[1]);
                    String typ = p[2];
                    String meno = p[3];
                    String priezvisko = p[4];
                    int rok = Integer.parseInt(p[5]);
                    db.pridajZamestnancaSPevnymId(id, typ, meno, priezvisko, rok);
                } else if (p[0].equals("S")) {
                    int idZ = Integer.parseInt(p[1]);
                    int idK = Integer.parseInt(p[2]);
                    UrovenSpoluprace uroven = UrovenSpoluprace.valueOf(p[3]);
                    db.pridajSpolupracu(idZ, idK, uroven);
                }
            }
            System.out.println("Data boli nacitane zo suboru.");
        } catch (Exception e) {
            System.out.println("Subor sa nepodarilo nacitat: " + e.getMessage());
        }
    }
}
