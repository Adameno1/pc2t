Databazovy system zamestnancov
Autor: studentsky projekt
Jazyk: Java
IDE: Eclipse

Spustenie:
1. Otvor Eclipse.
2. File -> Import -> Existing Projects into Workspace.
3. Vyber priecinok DatabazaZamestnancov_SK.
4. Spusti subor src/app/Main.java.

Projekt je spraveny jednoduchsie, studentskym stylom.
Obsahuje:
- OOP principy,
- abstraktnu triedu Zamestnanec,
- rozhranie Schopnost,
- dedicnost tried Analytik a BezpecnostnySpecialista,
- dynamicke struktury ArrayList a HashMap,
- ukladanie a nacitanie zo suboru,
- SQL zalohu vo forme jednoducheho SQL suboru databaza.sql.

Poznamka k SQL:
Aby projekt fungoval bez instalovania externych kniznic v Eclipse, SQL cast je spravena ako jednoducha SQL zaloha do suboru databaza.sql.
Program pri ukonceni vytvori SQL prikazy INSERT a pri spusteni sa pokusi tieto data nacitat naspat.
